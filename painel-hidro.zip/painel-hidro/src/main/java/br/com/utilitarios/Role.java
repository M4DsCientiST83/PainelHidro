package br.com.utilitarios;

public enum Role 
{
    ADMIN,
    CLIENTE
}
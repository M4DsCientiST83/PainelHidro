package br.com.leitura_imagens;

public interface Observador 
{
    void atualizar();
}
